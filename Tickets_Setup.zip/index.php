<html>
<head>
    <title>Tickets Test</title>
</head>

<body>
    <h3>This is a test</h3>
    <p><?php echo 'Current PHP version: ' . phpversion(); ?></p>
</body>
</html>